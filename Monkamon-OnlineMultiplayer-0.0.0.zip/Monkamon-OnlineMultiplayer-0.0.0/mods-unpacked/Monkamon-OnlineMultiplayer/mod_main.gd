extends Node

const MOD_ID := "Monkamon-OnlineMultiplayer"

func _init() -> void:
	var path := ModLoaderMod.get_unpacked_dir().path_join(MOD_ID).path_join("extensions/scenes/ui/name_input.gd")
	ModLoaderMod.install_script_extension(path)
	
	ModLoaderMod.extend_scene(
	"res://scenes/ui/name_input.tscn",
	func(original_scene: Node) -> Node:
		original_scene.free()
		return preload("res://mods-unpacked/Monkamon-OnlineMultiplayer/scenes/name_input.tscn").instantiate()
	)
