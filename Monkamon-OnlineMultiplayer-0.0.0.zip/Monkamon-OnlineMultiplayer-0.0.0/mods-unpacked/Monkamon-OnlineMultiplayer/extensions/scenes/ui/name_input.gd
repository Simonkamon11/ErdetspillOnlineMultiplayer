extends "res://scenes/ui/name_input.gd"

@onready var server_input: LineEdit = $Panel / ServerInput
@onready var online_btn: Button = $Panel / OnlineButton
