extends Node

const MOD_ID := "Monkamon-OnlineMultiplayer"

func _init() -> void:
	ModLoaderMod.extend_scene(
		"res://scenes/ui/name_input.tscn",
		func(original_scene: Node) -> Node:
			original_scene.free()
			return preload("res://mods-unpacked/Monkamon-OnlineMultiplayer/scenes/name_input.tscn").instantiate()
	)
	
	var name_input_path := ModLoaderMod.get_unpacked_dir().path_join(MOD_ID).path_join("extensions/scenes/ui/name_input.gd")
	ModLoaderMod.install_script_extension(name_input_path)
	var game_manager_path := ModLoaderMod.get_unpacked_dir().path_join(MOD_ID).path_join("extensions/components/game_manager.gd")
	ModLoaderMod.install_script_extension(game_manager_path)
	var postkasse_path := ModLoaderMod.get_unpacked_dir().path_join(MOD_ID).path_join("extensions/components/postkasse.gd")
	ModLoaderMod.install_script_extension(postkasse_path)
