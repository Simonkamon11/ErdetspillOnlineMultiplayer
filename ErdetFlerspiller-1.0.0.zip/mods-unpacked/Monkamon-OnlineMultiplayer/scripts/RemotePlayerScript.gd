extends CharacterBody3D

var player_id: int
var player_name: String

var player_position: Vector3
var player_rotation: Vector3

func _ready() -> void:
	player_position = global_position
	player_rotation = global_rotation
	
	var name_label = $NameLabel
	name_label.text = player_name
	name_label.modulate = Color(1, 1, 1, 1)
	name_label.font_size = 36
	name_label.pixel_size = 0.003
	name_label.outline_size = 12
	name_label.outline_modulate = Color(0, 0, 0, 1)
	name_label.no_depth_test = true

func _process(delta: float) -> void:
	global_position = player_position
	global_rotation = player_rotation
