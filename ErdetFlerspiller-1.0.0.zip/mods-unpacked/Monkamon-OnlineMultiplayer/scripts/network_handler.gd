extends Node

const PORT: int = 42069

const REGISTRY_URL := "https://monkamon.pythonanywhere.com"
var server_name: String = ""
var server_token: String = ""
var heartbeat_timer: Timer

var peer: ENetMultiplayerPeer

const REMOTE_PLAYER_SCENE = preload("res://mods-unpacked/Monkamon-OnlineMultiplayer/scenes/RemotePlayerScene.tscn")

var players := {}
var remote_player_data := {}
var remote_players := {}


func _ready() -> void:
	multiplayer.peer_connected.connect(_on_peer_connected)
	multiplayer.peer_disconnected.connect(_on_peer_disconnected)
	multiplayer.connected_to_server.connect(_on_connected_to_server)
	multiplayer.connection_failed.connect(_on_connection_failed)
	
	heartbeat_timer = Timer.new()
	heartbeat_timer.wait_time = 30.0
	heartbeat_timer.autostart = false
	heartbeat_timer.timeout.connect(send_heartbeat)
	add_child(heartbeat_timer)

func _process(_delta: float) -> void:
	if remote_player_data.is_empty():
		return

	if get_tree().current_scene == null:
		return

	if get_tree().current_scene.name != "World":
		return
	
	spawn_remote_players()

func _physics_process(_delta: float) -> void:
	if not multiplayer.has_multiplayer_peer():
		return

	var world := get_tree().current_scene

	if world == null or world.name != "World":
		return

	var player = world.get_node_or_null("NavigationRegion3D/PlayerCharacter")

	if player == null:
		return

	if multiplayer.is_server():
		update_remote_player.rpc(
			1,
			player.global_position,
			player.global_rotation
		)
	else:
		update_player_transform.rpc(
			player.global_position,
			player.global_rotation
		)


func _on_network_connected() -> void:
	var my_id := multiplayer.get_unique_id()

	if multiplayer.is_server():
		players[my_id] = {
			"name": GameManager.player_name
		}

		print("Registered host: ", GameManager.player_name, " ID: ", my_id)

		# Serveren trenger ikke RPC-e til seg selv.
		# Men når en klient kobler til, vil _on_peer_connected håndtere den.
	else:
		register_player.rpc_id(1, GameManager.player_name)


@rpc("any_peer")
func register_player(name: String) -> void:
	var id := multiplayer.get_remote_sender_id()

	players[id] = {
		"name": name
	}

	print("Player registered: ", name, " ID: ", id)

	# Serveren må registrere den nye spilleren lokalt
	receive_player(id, name)

	# Send alle eksisterende spillere til den nye klienten
	for player_id in players:
		var player = players[player_id]

		receive_player.rpc_id(id, player_id, player["name"])

	# Send den nye spilleren til alle andre klienter
	for player_id in players:
		if player_id != id and player_id != 1:
			receive_player.rpc_id(player_id, id, name)

@rpc("any_peer")
func test_message(message: String) -> void:
	print("Received: ", message)

@rpc
func receive_player(id: int, name: String) -> void:
	if id == multiplayer.get_unique_id():
		return

	if remote_players.has(id):
		return

	remote_player_data[id] = name

	print("Remote player queued: ", name, " ID: ", id)

func spawn_remote_players() -> void:
	var world = get_tree().current_scene

	if world == null:
		return
	
	if world.name != "World":
		return

	for id in remote_player_data:
		if remote_players.has(id):
			continue

		var remote_player = REMOTE_PLAYER_SCENE.instantiate()

		remote_player.player_id = id
		remote_player.player_name = remote_player_data[id]

		world.add_child(remote_player)

		remote_players[id] = remote_player

	remote_player_data.clear()

@rpc
func player_left(id: int) -> void:
	print("Player left: ", id)

	if remote_players.has(id):
		var remote_player = remote_players[id]

		if is_instance_valid(remote_player):
			remote_player.queue_free()

		remote_players.erase(id)

func _on_peer_connected(id: int) -> void:
	print("Peer connected: ", id)

	if not multiplayer.is_server():
		register_player.rpc_id(1, GameManager.player_name)

func _on_peer_disconnected(id: int) -> void:
	if not multiplayer.is_server():
		return

	if id in players:
		players.erase(id)
		print("Player disconnected: ", id)

		player_left.rpc(id)


func _on_connected_to_server() -> void:
	print("Successfully connected to server!")


func _on_connection_failed() -> void:
	print("Failed to connect to server!")


func start_server(server_name: String) -> void:
	self.server_name = server_name
	
	peer = ENetMultiplayerPeer.new()
	var error := peer.create_server(PORT)

	if error != OK:
		print("Failed to start server: ", error)
		return

	multiplayer.multiplayer_peer = peer
	
	players[multiplayer.get_unique_id()] = {
		"name": GameManager.player_name
	}

	print("Registered host: ", GameManager.player_name, " ID: ", multiplayer.get_unique_id())

	register_server(server_name)


func start_client(ip: String) -> void:
	print("Trying to connect to: ", ip, ":", PORT)

	peer = ENetMultiplayerPeer.new()
	var error := peer.create_client(ip, PORT)

	print("create_client result: ", error)

	if error != OK:
		print("Failed to connect: ", error)
		return

	multiplayer.multiplayer_peer = peer
	print("Client peer created")


func connect_to_server(server_name: String) -> void:
	var http := HTTPRequest.new()
	add_child(http)

	var url := REGISTRY_URL + "/server/" + server_name.uri_encode()

	var error := http.request(url)

	if error != OK:
		print("Failed to contact server registry: ", error)
		http.queue_free()
		return

	var result = await http.request_completed
	http.queue_free()

	var response_code: int = result[1]
	var body: PackedByteArray = result[3]

	print("Registry response: ", response_code)
	print("Registry body: ", body.get_string_from_utf8())

	if response_code == 200:
		var data: Dictionary = JSON.parse_string(body.get_string_from_utf8())

		if data.has("ip"):
			start_client(data["ip"])
			return

	if response_code == 404:
		start_server(server_name)
		return

	print("Registry error: ", response_code)

func register_server(server_name: String) -> void:
	var http := HTTPRequest.new()
	add_child(http)

	var register_data := JSON.stringify({
		"name": server_name
	})

	var headers := ["Content-Type: application/json"]

	var error := http.request(
		REGISTRY_URL + "/register",
		headers,
		HTTPClient.METHOD_POST,
		register_data
	)

	if error != OK:
		print("Failed to send register request: ", error)
		http.queue_free()
		return

	var result = await http.request_completed

	var response_code: int = result[1]
	var body: PackedByteArray = result[3]

	print("Register response: ", response_code)
	print("Register body: ", body.get_string_from_utf8())

	http.queue_free()

	if response_code != 200:
		print("Failed to register server.")
		return

	var data: Dictionary = JSON.parse_string(body.get_string_from_utf8())

	if data == null or not data.has("token"):
		print("Registry did not return a token.")
		return

	server_token = str(data["token"])

	print("Server registered successfully.")
	print("Server token received.")

	heartbeat_timer.start()

	print("Heartbeat started.")


func send_heartbeat() -> void:
	if server_name.is_empty() or server_token.is_empty():
		return

	var http := HTTPRequest.new()
	add_child(http)

	var headers := ["Content-Type: application/json"]

	var body := JSON.stringify({
		"name": server_name,
		"token": server_token
	})

	var error := http.request(
		REGISTRY_URL + "/heartbeat",
		headers,
		HTTPClient.METHOD_POST,
		body
	)

	if error != OK:
		http.queue_free()
		return

	var result = await http.request_completed
	http.queue_free()

	print("Heartbeat response: ", result[1])

func _wait_for_world() -> Node:
	for i in range(600):
		var current_scene = get_tree().current_scene

		if current_scene:
			var world = current_scene.get_node_or_null("World")

			if world:
				return world

		await get_tree().process_frame

	return null

@rpc("any_peer", "unreliable")
func update_player_transform(pos: Vector3, rot: Vector3) -> void:
	if not multiplayer.is_server():
		return

	var id := multiplayer.get_remote_sender_id()

	# Oppdater serverens egen RemotePlayer direkte
	update_remote_player(id, pos, rot)

	# Send til alle klienter
	for peer_id in multiplayer.get_peers():
		update_remote_player.rpc_id(peer_id, id, pos, rot)

@rpc("authority", "unreliable")
func update_remote_player(id: int, pos: Vector3, rot: Vector3) -> void:

	if id == multiplayer.get_unique_id():
		return

	if not remote_players.has(id):
		return

	var remote_player = remote_players[id]

	if not is_instance_valid(remote_player):
		return

	remote_player.player_position = pos
	remote_player.player_rotation = rot
