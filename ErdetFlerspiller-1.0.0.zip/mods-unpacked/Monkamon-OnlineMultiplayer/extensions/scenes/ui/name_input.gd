extends "res://scenes/ui/name_input.gd"

@onready var server_input: LineEdit = $Panel / ServerInput
@onready var online_btn: Button = $Panel / OnlineButton

const NETWORK_HANDLER = preload("res://mods-unpacked/Monkamon-OnlineMultiplayer/scripts/network_handler.gd")

func _ready() -> void:
	GameManager.server_name = "Offline"
	GameManager.is_online = false
	layer = 20
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	if bestefar_voice != null:
		audio.stream = bestefar_voice
	if audio.stream:
		audio.play()
	confirm_btn.pressed.connect(_on_confirm)
	online_btn.pressed.connect(_on_online)
	server_input.text_submitted.connect( func(_t: String) -> void : _on_online())
	server_input.text_changed.connect(_on_server_changed)
	name_input.text_submitted.connect( func(_t: String) -> void : _on_confirm())
	name_input.text_changed.connect(_on_name_changed)
	name_input.grab_focus()
	if error_label:
		error_label.visible = false

func _on_server_changed(_new_text: String) -> void :
	if error_label and error_label.visible:
		error_label.visible = false

func _on_online() -> void:
	if name_input.text == "":
		_show_error("Du må ha et spillernavn.")
		return
	
	if name_input.text.strip_edges().contains(" "):
		_show_error("Ingen mellomrom — bruk bindestrek (-) for dobbeltnavn.")
		return
	
	var player_name: String = _normalize_name(name_input.text)
	
	if player_name.length() < 2:
		_show_error("Navnet må være minst 2 bokstaver.")
		return
	
	if player_name.length() > 20:
		player_name = player_name.substr(0, 20)
	
	GameManager.player_name = player_name
	
	if server_input.text.strip_edges().contains(" "):
		_show_error("Ingen mellomrom på servernavn.")
		return
	
	var server_name: String = server_input.text
	
	if server_name.length() < 2:
		_show_error("Servernavnet må være minst 2 bokstaver.")
		return
	
	if server_name.length() > 20:
		_show_error("Servernavnet kan ikke være mer enn 20 bokstaver.")
		return
	
	GameManager.server_name = server_name
	GameManager.is_online = true
	
	var network_handler = get_tree().root.get_node_or_null("NetworkHandler")
	if network_handler == null:
		network_handler = NETWORK_HANDLER.new()
		network_handler.name = "NetworkHandler"
		get_tree().root.add_child(network_handler)
	
	network_handler.connect_to_server(server_name)
	
	var tween: = create_tween()
	var overlay: = ColorRect.new()
	overlay.color = Color.BLACK
	overlay.set_anchors_preset(Control.PRESET_FULL_RECT)
	overlay.mouse_filter = Control.MOUSE_FILTER_IGNORE
	$Panel.add_child(overlay)
	overlay.modulate.a = 0.0
	tween.tween_property(overlay, "modulate:a", 1.0, 0.8)
	await tween.finished
	get_tree().change_scene_to_file("res://scenes/ui/loading_screen.tscn")
