extends "res://components/postkasse.gd"

func _ready() -> void:
	if GameManager.is_online:
		label.text = str(GameManager.server_name)
	else:
		label.text = str(GameManager.player_name)
