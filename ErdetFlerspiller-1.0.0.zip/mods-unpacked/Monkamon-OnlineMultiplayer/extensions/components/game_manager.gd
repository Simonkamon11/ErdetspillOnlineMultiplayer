extends "res://components/game_manager.gd"

var server_name: String = "Offline"
var is_online: bool = false
